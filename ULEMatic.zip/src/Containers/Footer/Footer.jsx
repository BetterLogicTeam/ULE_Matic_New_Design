import React from 'react'

function Footer() {
  return (
    <div>

<div className="overlay toggle-icon"></div>
        <a href="javaScript:;" className="back-to-top"><i className='bx bxs-up-arrow-alt'></i></a>
        <footer className="page-footer footer">
            <p className="mb-0">Copyright © ulematicx.live 2022. All right reserved.</p>
        </footer>

    </div>
  )
}

export default Footer