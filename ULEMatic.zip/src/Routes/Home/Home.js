import React from 'react'
import Dashboard from '../../Containers/Dashboard/Dashboard'
function Home() {
  return (
    <div className='m-0 p-0'><Dashboard/></div>
  )
}

export default Home